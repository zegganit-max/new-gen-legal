# New Gen TV Analytics — pages légales (à publier sur GitHub Pages)

Ces 3 pages servent à remplir les champs obligatoires du formulaire TikTok for Developers :
**Terms of Service URL**, **Privacy Policy URL** et **official website URL** (Web/Desktop).

## Contenu
- `index.html` — page d'accueil (sert de « official website URL »)
- `terms.html` — Conditions d'utilisation
- `privacy.html` — Politique de confidentialité
- `app_icon_tiktok_1024.png` — icône d'app 1024x1024 (wordmark réel New Gen TV)

## Publication — méthode A (web, 3 minutes, sans token)
1. github.com → **New repository** → nom : `newgen-legal` → **Public** → *Add a README file* coché → Create.
2. Dans le repo : **Add file → Upload files** → glisse les 4 fichiers ci-dessus → **Commit changes**.
3. **Settings → Pages** → *Source* : `Deploy from a branch` → *Branch* : `main` / `/ (root)` → **Save**.
4. Attends 1 à 2 minutes. Tes URLs :
   - `https://zegganit-max.github.io/newgen-legal/`
   - `https://zegganit-max.github.io/newgen-legal/terms.html`
   - `https://zegganit-max.github.io/newgen-legal/privacy.html`

## Publication — méthode B (automatique, avec un token)
Donne un token GitHub (fine-grained, `Contents: Read and write` sur le repo) et les 4 fichiers sont poussés en une commande.

## Ce qu'il faut coller dans le formulaire TikTok
| Champ TikTok | Valeur |
|---|---|
| Terms of Service URL | `https://zegganit-max.github.io/newgen-legal/terms.html` |
| Privacy Policy URL | `https://zegganit-max.github.io/newgen-legal/privacy.html` |
| Website URL (Web/Desktop) | `https://zegganit-max.github.io/newgen-legal/` |
| App icon | `app_icon_tiktok_1024.png` |
| Redirect URI (Login Kit) | `http://127.0.0.1:*/callback/` |

Rappel : en **mode Sandbox**, la vérification de propriété des URLs n'est PAS exigée
(elle n'est requise que pour la Content Posting API). Il suffit que les pages soient en ligne.
